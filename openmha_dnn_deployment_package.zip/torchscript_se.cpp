// torchscript_se.cpp
// Minimal openMHA TorchScript wave-to-wave plugin skeleton

#include <string>
#include <stdexcept>
#include <torch/script.h>

#include "mha_plugin.hh"

class torchscript_se_t : public MHAPlugin::plugin_t<MHAPlugin::runtime_cfg_t> {
public:
    torchscript_se_t(algo_comm_t & ac, const std::string & name)
        : MHAPlugin::plugin_t<MHAPlugin::runtime_cfg_t>(ac, name),
          model_path_(""), device_("cpu"), gain_(1.0f) {

        insert_item("model", &model_path_, "Path to TorchScript .pt model");
        insert_item("device", &device_, "cpu or cuda");
        insert_item("gain", &gain_, "Optional output gain");
    }

    void prepare(mhaconfig_t & cfg) override {
        if (model_path_.empty())
            throw std::runtime_error("Model path not set");

        module_ = torch::jit::load(model_path_);
        module_.eval();

        if (device_ == "cuda" && torch::cuda::is_available()) {
            module_.to(torch::kCUDA);
            device_kind_ = torch::kCUDA;
        } else {
            module_.to(torch::kCPU);
            device_kind_ = torch::kCPU;
        }
    }

    mha_wave_t* process(mha_wave_t* in) override {
        // NOTE:
        // You must adapt this section to your specific openMHA waveform structure.
        // Convert input buffer to torch tensor, run inference, copy output back.

        return in; // passthrough placeholder
    }

private:
    std::string model_path_;
    std::string device_;
    float gain_;

    torch::jit::Module module_;
    torch::DeviceType device_kind_{torch::kCPU};
};

MHAPLUGIN_EXPORT torchscript_se_t;
